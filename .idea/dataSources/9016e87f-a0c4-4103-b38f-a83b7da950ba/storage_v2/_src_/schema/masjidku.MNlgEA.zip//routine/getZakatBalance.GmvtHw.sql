create
    definer = root@localhost function getZakatBalance() returns double deterministic
BEGIN
    DECLARE zakat_in double;
    DECLARE zakat_out double;

    SELECT SUM(jumlah) INTO zakat_in
    FROM pemberi_zakat;

    SELECT SUM(jumlah) INTO zakat_out
    FROM penerima_zakat;

    RETURN (zakat_in-zakat_out);

end;

