create
    definer = root@localhost function getInfakYatimBalance() returns double deterministic
BEGIN
    DECLARE infakYatim_in double;
    DECLARE infakYatim_out double;

    SELECT SUM(jumlah) INTO infakYatim_in
    FROM infak_anakyatim;

    SELECT SUM(jumlah) INTO infakYatim_out
    FROM penerima_anakyatim;

    RETURN (infakYatim_in-infakYatim_out);

end;

