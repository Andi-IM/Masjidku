create
    definer = root@localhost function getPembangunanBalance() returns double deterministic
BEGIN
    DECLARE pembangunan_in double;
    DECLARE pembangunan_out double;

    SELECT SUM(jumlah) INTO pembangunan_in
    FROM infak_pembangunan;

    SELECT SUM(jumlah) INTO pembangunan_out
    FROM pembangunan_keluar;

    RETURN (pembangunan_in-pembangunan_out);

end;

