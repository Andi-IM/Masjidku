create
    definer = root@localhost function getOperationalBalance() returns double deterministic
BEGIN
    DECLARE operational_in double;
    DECLARE operational_out double;

    SELECT SUM(jumlah) INTO operational_in
    FROM infak_operasional;

    SELECT SUM(jumlah) INTO operational_out
    FROM operasional_keluar;

    RETURN (operational_in-operational_out);

end;

