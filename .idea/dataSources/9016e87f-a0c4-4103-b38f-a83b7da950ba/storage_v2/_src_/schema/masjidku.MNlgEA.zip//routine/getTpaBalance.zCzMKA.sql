create
    definer = root@localhost function getTpaBalance() returns double deterministic
BEGIN
    DECLARE tpa_in double;
    DECLARE tpa_out double;

    SELECT SUM(jumlah) INTO tpa_in
    FROM infak_tpa;

    SELECT SUM(jumlah) INTO tpa_out
    FROM tpa_keluar;

    RETURN (tpa_in-tpa_out);

end;

